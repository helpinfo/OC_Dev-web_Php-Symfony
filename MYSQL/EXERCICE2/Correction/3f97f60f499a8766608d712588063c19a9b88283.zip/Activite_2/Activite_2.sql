-- Au préalable, je défini le français comme langue utilisée dans la traduction des dates.
SET lc_time_names = 'fr_FR';

-- PAGE ACCUEIL : articles (triés du plus récent au plus vieux), date de publication format "12/10/2014", pseudo, titre et resume, et le nombre de commentaires pour chaque article.
-- POUR DES RAISONS DE LISIBILITE DES RESULTATS, JE N'AI PAS INCLU LE CHAMPS 'RESUME' DANS LE SELECT.  

SELECT DATE_FORMAT(date_publication, '%d/%m/%Y') AS date_publi, titre, 
        pseudo, COUNT(commentaire.article_id) AS nb_comment
FROM article
LEFT JOIN Commentaire ON article.id = Commentaire.article_id
INNER JOIN Utilisateur ON article.auteur_id = Utilisateur.id
GROUP BY titre
ORDER BY date_publi DESC;


-- PAGE AUTEUR (Utilisateur.id = 2) : pseudo, date de publication (format "12 Octobre '14"), titre et resumé de chaque article triés du plus récent au plus vieux. 
-- POUR DES RAISONS DE LISIBILITE DES RESULTATS, JE N'AI PAS INCLU LE CHAMPS 'RESUME' DANS LE SELECT.

SELECT pseudo AS auteur, DATE_FORMAT(Article.date_publication, '%d %M ''%y') AS date_publi, titre
FROM article
INNER JOIN Utilisateur ON article.auteur_id = Utilisateur.id
WHERE auteur_id = 2
ORDER BY date_publi DESC;

-- PAGE CATEGORIE id = 3: date de publication (format "12/10/2014 - 17:47"), pseudo de l'auteur, titre et resumé de chaque article (du + recent au plus vieux).
-- POUR DES RAISONS DE LISIBILITE DES RESULTATS, JE N'AI PAS INCLU LE CHAMPS 'RESUME' DANS LE SELECT.

SELECT Categorie.nom AS Categorie, DATE_FORMAT(Article.date_publication, '%d/%m/%Y - %k:%i')
        AS date_publi, pseudo AS auteur, titre
FROM Article
INNER JOIN Categorie_article ON Article.id = Categorie_article.article_id
INNER JOIN Categorie ON Categorie_article.categorie_id = Categorie.id
INNER JOIN Utilisateur ON Article.auteur_id = Utilisateur.id
WHERE Categorie.id = 3
ORDER BY date_publi DESC;

-- PAGE ARTICLE (id = 4) : date de publication (format "12 Octobre 2014 à 17 heures 47"), titre, contenu, le nom des categories, pseudo de l'auteur.
-- POUR DES RAISONS DE LISIBILITE DES RESULTATS, JE N'AI PAS INCLU LE CHAMPS 'CONTENU' DANS LE SELECT.

SELECT DATE_FORMAT(date_publication, '%d %M %Y à %k heures %i') AS date_publi, titre, 
        GROUP_CONCAT(Categorie.nom) AS categorie, pseudo AS auteur
FROM Article 
INNER JOIN Utilisateur ON article.auteur_id = Utilisateur.id
INNER JOIN Categorie_article ON Article.id = Categorie_article.article_id
INNER JOIN Categorie ON Categorie_article.categorie_id = Categorie.id
WHERE Article.id = 4;

-- Page article id = 4 : on recupere tous les commentaires de l'article id = 4

SELECT Commentaire.contenu,
              DATE_FORMAT(Commentaire.date_commentaire, '%d/%m/%Y'), Utilisateur.pseudo
FROM Commentaire
LEFT JOIN Utilisateur ON Commentaire.auteur_id = Utilisateur.id
WHERE Commentaire.article_id = 4
ORDER BY Commentaire.date_commentaire;
